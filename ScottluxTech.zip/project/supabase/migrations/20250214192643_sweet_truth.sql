/*
  # Create survey responses table

  1. New Tables
    - `survey_responses`
      - `id` (uuid, primary key)
      - `service_type` (text) - Type of service selected
      - `package_type` (text) - Package/pricing tier selected
      - `company_name` (text)
      - `full_name` (text)
      - `email` (text)
      - `phone` (text)
      - `company_size` (text)
      - `budget` (text)
      - `timeline` (text)
      - `project_description` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `survey_responses` table
    - Add policy for inserting new responses
    - Add policy for reading own responses
*/

CREATE TABLE IF NOT EXISTS survey_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type text NOT NULL,
  package_type text NOT NULL,
  company_name text,
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  company_size text,
  budget text,
  timeline text,
  project_description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE survey_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert survey responses"
  ON survey_responses
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can read own responses"
  ON survey_responses
  FOR SELECT
  TO authenticated
  USING (email = auth.email());