import React from 'react';
import { Code, Laptop, Smartphone, Globe } from 'lucide-react';
import PricingCard from '../components/PricingCard';

const features = [
  {
    icon: Laptop,
    title: 'Modern Technologies',
    description: 'Built with the latest frameworks and tools like React, Vue.js, and Node.js'
  },
  {
    icon: Smartphone,
    title: 'Responsive Design',
    description: 'Websites that look and work perfectly on all devices and screen sizes'
  },
  {
    icon: Globe,
    title: 'SEO Optimized',
    description: 'Built with best practices to help your site rank better in search engines'
  }
];

const packages = [
  {
    name: 'Basic',
    price: 999,
    features: [
      'Single Page Website',
      'Mobile Responsive Design',
      'Contact Form',
      '2 Rounds of Revisions',
      '1 Month Support'
    ]
  },
  {
    name: 'Professional',
    price: 2499,
    features: [
      'Up to 5 Pages Website',
      'Custom Animations',
      'CMS Integration',
      'SEO Optimization',
      '3 Months Support'
    ]
  },
  {
    name: 'Enterprise',
    price: 4999,
    features: [
      'Custom Web Application',
      'E-commerce Integration',
      'Advanced Analytics',
      'API Development',
      '6 Months Support'
    ]
  }
];

const WebDevelopment = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Code className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Web Development Services</h1>
            <p className="text-xl text-blue-100">
              Transform your digital presence with custom web solutions that drive results
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <feature.icon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Development Process</h2>
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-blue-200" />
              
              {/* Timeline items */}
              <div className="space-y-12">
                {[
                  { title: 'Discovery', content: 'Understanding your needs and project requirements' },
                  { title: 'Planning', content: 'Creating detailed project roadmap and wireframes' },
                  { title: 'Development', content: 'Building your website with regular updates' },
                  { title: 'Testing', content: 'Thorough testing across devices and browsers' },
                  { title: 'Launch', content: 'Deploying your website and providing training' }
                ].map((item, index) => (
                  <div key={index} className="relative">
                    <div className="relative flex items-center">
                      <div className="flex-1 text-right pr-8">
                        <h3 className="text-xl font-bold">{item.title}</h3>
                      </div>
                      <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-600 rounded-full" />
                      <div className="flex-1 pl-8">
                        <p className="text-gray-600">{item.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Pick your perfect plan</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {packages.map((pkg, index) => (
              <PricingCard
                key={index}
                name={pkg.name}
                price={pkg.price}
                features={pkg.features}
                isPopular={index === 1}
                serviceType="Web Development"
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default WebDevelopment;