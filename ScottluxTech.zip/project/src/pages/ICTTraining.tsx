import React from 'react';
import { GraduationCap, BookOpen, Users, Award } from 'lucide-react';
import PricingCard from '../components/PricingCard';

const features = [
  {
    icon: BookOpen,
    title: 'Comprehensive Curriculum',
    description: 'Structured learning paths covering essential tech skills'
  },
  {
    icon: Users,
    title: 'Expert Instructors',
    description: 'Learn from experienced professionals in the field'
  },
  {
    icon: Award,
    title: 'Certification',
    description: 'Earn recognized certificates upon completion'
  }
];

const packages = [
  {
    name: 'Basic',
    price: 299,
    features: [
      'Online Course Access',
      'Basic Curriculum',
      'Email Support',
      'Course Certificate',
      '1 Month Access'
    ]
  },
  {
    name: 'Professional',
    price: 799,
    features: [
      'Live Online Sessions',
      'Advanced Curriculum',
      'Project-based Learning',
      'Mentorship Support',
      '3 Months Access'
    ]
  },
  {
    name: 'Enterprise',
    price: 1999,
    features: [
      'Custom Training Program',
      'On-site Training',
      'Hands-on Workshops',
      'Team Assessments',
      'Unlimited Access'
    ]
  }
];

const ICTTraining = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-green-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <GraduationCap className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">ICT Training Services</h1>
            <p className="text-xl text-green-100">
              Empower your team with cutting-edge technology skills
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <feature.icon className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Training Areas */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Training Areas</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: 'Web Development',
                topics: ['HTML/CSS', 'JavaScript', 'React', 'Node.js']
              },
              {
                title: 'Information Security',
                topics: ['Network Security', 'Cybersecurity', 'Ethical Hacking']
              },
              {
                title: 'Cloud Computing',
                topics: ['AWS', 'Azure', 'Cloud Security']
              },
              {
                title: 'Database Management',
                topics: ['SQL', 'MongoDB', 'Database Design']
              },
              {
                title: 'DevOps',
                topics: ['Git', 'Docker', 'CI/CD', 'Kubernetes']
              },
              {
                title: 'Mobile Development',
                topics: ['React Native', 'iOS', 'Android']
              }
            ].map((area, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4">{area.title}</h3>
                <ul className="space-y-2">
                  {area.topics.map((topic, idx) => (
                    <li key={idx} className="flex items-center text-gray-600">
                      <BookOpen className="w-4 h-4 text-green-600 mr-2" />
                      {topic}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Pick your perfect plan</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {packages.map((pkg, index) => (
              <PricingCard
                key={index}
                name={pkg.name}
                price={pkg.price}
                features={pkg.features}
                isPopular={index === 1}
                serviceType="ICT Training"
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ICTTraining;