import React from 'react';
import { Briefcase, LineChart, Target, Users } from 'lucide-react';
import PricingCard from '../components/PricingCard';

const features = [
  {
    icon: LineChart,
    title: 'Business Analysis',
    description: 'In-depth analysis of your business processes and technology needs'
  },
  {
    icon: Target,
    title: 'Strategic Planning',
    description: 'Develop comprehensive strategies for digital transformation'
  },
  {
    icon: Users,
    title: 'Implementation Support',
    description: 'Guide your team through the implementation of new solutions'
  }
];

const packages = [
  {
    name: 'Startup',
    price: 1499,
    features: [
      'Initial Business Analysis',
      'Technology Assessment',
      'Basic Strategy Planning',
      'Monthly Progress Review',
      '2 Hours Monthly Consultation'
    ]
  },
  {
    name: 'Growth',
    price: 2999,
    features: [
      'Comprehensive Analysis',
      'Digital Transformation Strategy',
      'Implementation Roadmap',
      'Weekly Progress Reviews',
      '8 Hours Monthly Consultation'
    ]
  },
  {
    name: 'Enterprise',
    price: 5999,
    features: [
      'Full-Scale Business Analysis',
      'Custom Technology Strategy',
      'Dedicated Project Manager',
      'Daily Support Access',
      'Unlimited Consultation'
    ]
  }
];

const Consultancy = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 to-purple-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Briefcase className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Business Technology Consultancy</h1>
            <p className="text-xl text-purple-100">
              Transform your business with expert technology consulting and strategic guidance
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <feature.icon className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Consulting Areas */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Consulting Areas</h2>
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Digital Transformation',
                items: ['Process Automation', 'Cloud Migration', 'Digital Workflow']
              },
              {
                title: 'Technology Strategy',
                items: ['IT Infrastructure', 'Software Selection', 'Tech Stack Planning']
              },
              {
                title: 'Business Optimization',
                items: ['Process Analysis', 'Efficiency Improvement', 'Cost Optimization']
              },
              {
                title: 'Implementation Support',
                items: ['Project Management', 'Change Management', 'Team Training']
              }
            ].map((section, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4">{section.title}</h3>
                <ul className="space-y-2">
                  {section.items.map((item, idx) => (
                    <li key={idx} className="flex items-center text-gray-600">
                      <Target className="w-4 h-4 text-purple-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Consulting Process</h2>
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-purple-200" />
              <div className="space-y-12">
                {[
                  { title: 'Discovery', content: 'Understanding your business needs and challenges' },
                  { title: 'Analysis', content: 'Detailed assessment of current processes and systems' },
                  { title: 'Strategy', content: 'Developing a tailored technology roadmap' },
                  { title: 'Implementation', content: 'Supporting the execution of recommended solutions' },
                  { title: 'Optimization', content: 'Continuous improvement and refinement' }
                ].map((item, index) => (
                  <div key={index} className="relative">
                    <div className="relative flex items-center">
                      <div className="flex-1 text-right pr-8">
                        <h3 className="text-xl font-bold">{item.title}</h3>
                      </div>
                      <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-purple-600 rounded-full" />
                      <div className="flex-1 pl-8">
                        <p className="text-gray-600">{item.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Consulting Packages</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {packages.map((pkg, index) => (
              <PricingCard
                key={index}
                name={pkg.name}
                price={pkg.price}
                features={pkg.features}
                isPopular={index === 1}
                serviceType="Consultancy"
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Consultancy;