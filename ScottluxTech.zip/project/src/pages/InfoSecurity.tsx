import React from 'react';
import { Shield, Lock, AlertTriangle, FileSearch } from 'lucide-react';
import PricingCard from '../components/PricingCard';

const features = [
  {
    icon: Lock,
    title: 'Advanced Protection',
    description: 'Comprehensive security measures to protect against modern threats'
  },
  {
    icon: AlertTriangle,
    title: 'Threat Detection',
    description: 'Real-time monitoring and early warning system for security incidents'
  },
  {
    icon: FileSearch,
    title: 'Security Audits',
    description: 'Regular assessments to identify and address vulnerabilities'
  }
];

const packages = [
  {
    name: 'Basic',
    price: 799,
    features: [
      'Security Assessment',
      'Vulnerability Scanning',
      'Basic Security Training',
      'Monthly Reports',
      'Email Support'
    ]
  },
  {
    name: 'Professional',
    price: 1999,
    features: [
      'Penetration Testing',
      'Security Monitoring',
      'Incident Response Plan',
      'Weekly Reports',
      '24/7 Email Support'
    ]
  },
  {
    name: 'Enterprise',
    price: 3999,
    features: [
      'Advanced Threat Protection',
      'SIEM Implementation',
      'Custom Security Policies',
      'Real-time Monitoring',
      '24/7 Phone Support'
    ]
  }
];

const InfoSecurity = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-indigo-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Shield className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Information Security Services</h1>
            <p className="text-xl text-indigo-100">
              Protect your digital assets with enterprise-grade security solutions
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <feature.icon className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Approach */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Security Approach</h2>
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Prevention',
                items: ['Threat Assessment', 'Security Controls', 'Access Management']
              },
              {
                title: 'Detection',
                items: ['Real-time Monitoring', 'Incident Detection', 'Behavioral Analysis']
              },
              {
                title: 'Response',
                items: ['Incident Response', 'Threat Containment', 'Recovery Planning']
              },
              {
                title: 'Compliance',
                items: ['Policy Development', 'Regular Audits', 'Regulatory Compliance']
              }
            ].map((section, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4">{section.title}</h3>
                <ul className="space-y-2">
                  {section.items.map((item, idx) => (
                    <li key={idx} className="flex items-center text-gray-600">
                      <Shield className="w-4 h-4 text-indigo-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Pick your perfect plan</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {packages.map((pkg, index) => (
              <PricingCard
                key={index}
                name={pkg.name}
                price={pkg.price}
                features={pkg.features}
                isPopular={index === 1}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default InfoSecurity;