import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Github, Linkedin, Mail, Phone } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Contact from './components/Contact';
import Services from './components/Services';
import WebDevelopment from './pages/WebDevelopment';
import Consultancy from './pages/Consultancy';
import ICTTraining from './pages/ICTTraining';
import Survey from './pages/Survey';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Toaster position="top-right" />
        <Header />
        <Routes>
          <Route path="/" element={
            <main>
              <Hero />
              <About />
              <Services />
              <Experience />
              <Projects />
              <Skills />
              <Contact />
            </main>
          } />
          <Route path="/services/web-development" element={<WebDevelopment />} />
          <Route path="/services/consultancy" element={<Consultancy />} />
          <Route path="/services/ict-training" element={<ICTTraining />} />
          <Route path="/survey" element={<Survey />} />
        </Routes>
        <footer className="bg-gray-900 text-white py-8">
          <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm">© 2024 Scottlux Tech. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a 
                href="https://github.com/scottluxtech" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-blue-400 transition-colors duration-300"
              >
                <Github size={20} />
              </a>
              <a 
                href="https://www.linkedin.com/company/scottlux-tech" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-blue-400 transition-colors duration-300"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="mailto:contact@scottluxtech.com" 
                className="hover:text-blue-400 transition-colors duration-300"
              >
                <Mail size={20} />
              </a>
              <a 
                href="tel:+905010845958" 
                className="hover:text-blue-400 transition-colors duration-300"
              >
                <Phone size={20} />
              </a>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;