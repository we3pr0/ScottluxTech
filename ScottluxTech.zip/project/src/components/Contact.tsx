import React, { useState, useRef } from 'react';
import { Mail, Phone, Linkedin, MapPin, Loader2 } from 'lucide-react';
import emailjs from '@emailjs/browser';
import toast, { Toaster } from 'react-hot-toast';

const Contact = () => {
  const [isLoading, setIsLoading] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    setIsLoading(true);
    try {
      const result = await emailjs.sendForm(
        'service_8u9x08p', // Replace with your EmailJS service ID
        'template_irqyz3i', // Replace with your EmailJS template ID
        formRef.current,
        'iUNrFLQn-55WMfrod' // Replace with your EmailJS public key
      );
      
      if (result.text === 'OK') {
        toast.success('Message sent successfully!');
        formRef.current.reset();
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      toast.error('Failed to send message. Please try again.');
      console.error('Error sending email:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <Toaster position="top-right" />
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">Get in Touch</h2>
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6 animate-slide-left">
              <h3 className="text-2xl font-semibold mb-4">Contact Information</h3>
              <div className="flex items-center space-x-4 hover-lift">
                <Mail className="text-blue-600 animate-bounce-slow" size={24} />
                <div>
                  <p className="font-medium">Email</p>
                  <a
                    href="mailto:lekeboj@gmail.com"
                    className="text-blue-600 hover:text-blue-800 transition-colors duration-300"
                  >
                    lekeboj@gmail.com
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-4 hover-lift">
                <Phone className="text-blue-600 animate-bounce-slow" size={24} />
                <div>
                  <p className="font-medium">Phone</p>
                  <a
                    href="tel:+905010845958"
                    className="text-blue-600 hover:text-blue-800 transition-colors duration-300"
                  >
                    +90 501 0845 958
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-4 hover-lift">
                <Linkedin className="text-blue-600 animate-bounce-slow" size={24} />
                <div>
                  <p className="font-medium">LinkedIn</p>
                  <a
                    href="https://www.linkedin.com/in/leke-bolaji-b89932243"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 transition-colors duration-300"
                  >
                    Leke Bolaji
                  </a>
                </div>
              </div>
              <div className="flex items-center space-x-4 hover-lift">
                <MapPin className="text-blue-600 animate-bounce-slow" size={24} />
                <div>
                  <p className="font-medium">Location</p>
                  <p>Izmir, Turkey</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg animate-slide-right">
              <h3 className="text-2xl font-semibold mb-4">Send a Message</h3>
              <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
                <div className="transform transition-all duration-300 hover:translate-y-[-2px]">
                  <label htmlFor="user_name" className="block text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <input
                    type="text"
                    id="user_name"
                    name="user_name"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-all duration-300"
                  />
                </div>
                <div className="transform transition-all duration-300 hover:translate-y-[-2px]">
                  <label htmlFor="user_email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="user_email"
                    name="user_email"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-all duration-300"
                  />
                </div>
                <div className="transform transition-all duration-300 hover:translate-y-[-2px]">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={4}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-all duration-300"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-all duration-300 hover:shadow-lg hover-lift disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="animate-spin mr-2" size={20} />
                      Sending...
                    </>
                  ) : (
                    'Send Message'
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;