import React from 'react';

const Hero = () => {
  return (
    <section className="pt-20 pb-32 bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 pt-16">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-8 md:mb-0 animate-slide-left">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Hi, I'm Bolaji Oyeleke
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              A detail-oriented and results-driven professional focused on application development and digital transformation.
            </p>
            <div className="flex space-x-4">
              <a
                href="#contact"
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-all duration-300 hover:shadow-lg hover-lift"
              >
                Get in Touch
              </a>
              <a
                href="#projects"
                className="bg-white text-blue-600 px-6 py-3 rounded-lg border border-blue-600 hover:bg-blue-50 transition-all duration-300 hover:shadow-lg hover-lift"
              >
                View Projects
              </a>
            </div>
          </div>
          <div className="md:w-1/2 animate-slide-right">
            <img
              src="https://media.licdn.com/dms/image/v2/D4D03AQFe5Ju7xWboHw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1700052656639?e=1744243200&v=beta&t=XDaOzZVReg3dTD4NNXEpJ9Xs2mKHobEnHPbRTKoJV58"
              alt="Professional headshot"
              className="rounded-full w-64 h-64 object-cover mx-auto shadow-lg hover-scale"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;