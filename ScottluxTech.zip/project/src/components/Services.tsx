import React from 'react';
import { Link } from 'react-router-dom';
import { Code, Briefcase, GraduationCap, ArrowRight } from 'lucide-react';

const services = [
  {
    title: 'Web Development',
    icon: Code,
    description: 'Creating modern, secure web applications with the integration of cutting-edge technologies.',
    link: '/services/web-development',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1000'
  },
  {
    title: 'Consultancy',
    icon: Briefcase,
    description: 'Strategic technology consulting to transform and optimize your personal or business operations.',
    link: '/services/consultancy',
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=1000'
  },
  {
    title: 'ICT Training',
    icon: GraduationCap,
    description: 'Comprehensive technology training programs for individuals and organizations.',
    link: '/services/ict-training',
    image: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80&w=1000'
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {services.map((service, index) => (
            <Link
              key={index}
              to={service.link}
              className="group relative overflow-hidden rounded-xl shadow-lg transform hover:-translate-y-2 transition-all duration-300"
            >
              <div className="relative h-64">
                <div className="absolute inset-0">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/20" />
                </div>
                <div className="absolute inset-0 p-6 flex flex-col justify-between">
                  <div className="flex items-center">
                    <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg">
                      <service.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{service.title}</h3>
                    <p className="text-white/90 mb-4">{service.description}</p>
                    <div className="flex items-center text-white group-hover:text-blue-400 transition-colors duration-300">
                      <span className="mr-2">Learn More</span>
                      <ArrowRight className="w-5 h-5 transform group-hover:translate-x-2 transition-transform duration-300" />
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Services;