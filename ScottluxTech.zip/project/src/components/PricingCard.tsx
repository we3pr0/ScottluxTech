import React, { useState } from 'react';
import { Check, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PricingCardProps {
  name: string;
  price: number;
  features: string[];
  isPopular?: boolean;
  serviceType: string;
}

const PricingCard: React.FC<PricingCardProps> = ({ name, price, features, isPopular, serviceType }) => {
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();

  const handleGetStarted = () => {
    // Navigate to survey page with service type and package as URL parameters
    navigate(`/survey?service=${encodeURIComponent(serviceType)}&package=${encodeURIComponent(name)}`);
  };

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative bg-white rounded-xl shadow-lg p-8 transform transition-all duration-300 ${
        isHovered ? 'scale-105' : ''
      } ${isPopular ? 'border-2 border-blue-500' : ''}`}
    >
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
            Most Popular
          </span>
        </div>
      )}
      
      <h4 className="text-xl font-bold mb-4">{name}</h4>
      <div className="mb-6">
        <span className="text-4xl font-bold">${price}</span>
        <span className="text-gray-600">/project</span>
      </div>
      
      <ul className="space-y-4 mb-8">
        {features.map((feature, idx) => (
          <li key={idx} className="flex items-center text-gray-600">
            <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      
      <button
        onClick={handleGetStarted}
        className={`w-full px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
          isPopular
            ? 'bg-blue-600 text-white hover:bg-blue-700'
            : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
        } transform ${isHovered ? 'scale-105' : ''}`}
      >
        Get Started
      </button>
    </div>
  );
};

export default PricingCard;