import React from 'react';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'Endpoint Security in Supply Chains',
    description: 'A case study of Cyber Security System Selection presented at the 4th International Symposium of Scientific Research and Innovative Studies conference.',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=800',
    tags: ['Cybersecurity', 'Supply Chain', 'Research'],
    documentUrl: 'https://scottluxtech.com/documents/endpoint-security-case-study.pdf'
  },
  {
    title: 'Supply Chain API Data Sharing',
    description: 'Research project focused on improving supply chain operations through API-based solutions for efficient data sharing and communication.',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800',
    tags: ['API', 'Supply Chain', 'Data Integration'],
    documentUrl: 'https://scottluxtech.com/documents/supply-chain-api-research.pdf'
  },
];

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">Featured Projects</h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto stagger-children">
          {projects.map((project, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-500 animate-fade-in hover-scale"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full transition-all duration-300 hover:bg-blue-200"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4">
                  <a
                    href={project.documentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-blue-600 hover:text-blue-800 transition-colors duration-300"
                  >
                    <ExternalLink className="mr-2" size={20} />
                    View Document
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;