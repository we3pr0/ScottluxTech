import React from 'react';

const skillCategories = [
  {
    title: 'Tech Stacks',
    skills: [
      /*'Endpoint Security',
      'Network Security',*/
      'JavaScript',
      'React.js',
      'Node.js',
      'MongoDB / MySQL',
      'User Authentication',
      'SIEM (Splunk)',
      'API Development',
      /*'Python',
      'Linux',
      */
    ],
  },
  {
    title: 'Licenses & Certifications',
    badges: [
      {
        image: "https://media.licdn.com/dms/image/v2/D4D2DAQFWR1af1OGtqQ/profile-treasury-image-shrink_160_160/profile-treasury-image-shrink_160_160/0/1706174845286?e=1740171600&v=beta&t=EdhtFkEVi5Ih4Avoz-hNlnjlFRQQ_4IKA7QAaIPb9x4",
        title: "McKinsey Forward Foundation Program",
        issuer: "McKinsey & Company",
        link: "https://www.credly.com/badges/e8e9414a-0846-4c4c-8669-f5a8fd9e31fb/public_url"
      },
      {
        image: "https://media.licdn.com/dms/image/v2/D4E0BAQEANDNp1O78-g/company-logo_100_100/company-logo_100_100/0/1692269546870?e=1746662400&v=beta&t=fvqNZK3DKSqS7o3ZKrob9oPlpTpRjZUGevTUjHLpEiY",
        title: "CC",
        issuer: "ISC²",
        credentialId: "1327379"
      },
      /*{
        image: "https://media.licdn.com/dms/image/v2/D560BAQFIQ_eNe9b1jg/company-logo_100_100/company-logo_100_100/0/1688016806462/fortinet_logo?e=1746662400&v=beta&t=84YtcZu3RBLycDgy5f4Wl-9YUagUZk7daTik_xarC04",
        title: "NSE 1 Network Security Associate",
        issuer: "Fortinet",
        credentialId: "vpsQHgyIYj"
      },
      {
        image: "https://media.licdn.com/dms/image/v2/D560BAQFIQ_eNe9b1jg/company-logo_100_100/company-logo_100_100/0/1688016806462/fortinet_logo?e=1746662400&v=beta&t=84YtcZu3RBLycDgy5f4Wl-9YUagUZk7daTik_xarC04",
        title: "NSE 2 Network Security Associate",
        issuer: "Fortinet",
        credentialId: "vpsQHgyIYj"
      },*/
      {
        image: "https://media.licdn.com/dms/image/v2/C510BAQFWz2ZDRZSVdQ/company-logo_100_100/company-logo_100_100/0/1631323424476?e=1746662400&v=beta&t=b6Qi3BbyYeg1jURneiABIa5lAWsytBXyNG6R7dpZaFg",
        title: "Web Development",
        issuer: "NIIT Technologies",
        
      }
      
    ]
  },
  {
    title: 'Core Competencies',
    skills: [
      'Communication',
      'Problem Solving',
      'Security Analysis',
      'Programming Logic',
      'Self-motivated',
      'Continuous Learning',
    ],
  },
];

const Skills = () => {
  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">Skills & Expertise</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto stagger-children">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-all duration-300 animate-fade-in hover-lift"
            >
              <h3 className="text-xl font-bold mb-4 text-blue-600">
                {category.title}
              </h3>
              {'skills' in category ? (
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="bg-gray-100 text-gray-800 text-sm px-3 py-1 rounded-full transition-all duration-300 hover:bg-blue-100 hover:text-blue-800"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {category.badges.map((badge, idx) => (
                    <div key={idx} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 transition-all duration-300">
                      <img src={badge.image} alt={badge.title} className="w-12 h-12 rounded-full" />
                      <div>
                        <h4 className="font-medium text-gray-900">{badge.title}</h4>
                        <p className="text-sm text-gray-600">{badge.issuer}</p>
                        {badge.credentialId && (
                          <p className="text-xs text-gray-500">Credential ID: {badge.credentialId}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;