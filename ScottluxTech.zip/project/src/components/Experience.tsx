import React from 'react';
import { Code, Shield, Laptop, GraduationCap, ArrowRight } from 'lucide-react';

const experiences = [
  {
    icon: Laptop,
    title: 'Digital Literacy',
    description: 'Foundation in technology and digital skills',
    color: 'bg-emerald-500',
    iconColor: 'text-emerald-500',
  },
  {
    icon: Shield,
    title: 'IT Support',
    description: 'Technical support and system maintenance',
    color: 'bg-blue-500',
    iconColor: 'text-blue-500',
  },
  {
    icon: Code,
    title: 'Web Development & Security',
    description: 'Full-stack development and security implementation',
    color: 'bg-purple-500',
    iconColor: 'text-purple-500',
  },
  {
    icon: GraduationCap,
    title: 'Training & Consulting',
    description: 'Educational leadership and technical consulting',
    color: 'bg-orange-500',
    iconColor: 'text-orange-500',
  },
];

const Experience = () => {
  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">Career Journey</h2>
        
        <div className="max-w-4xl mx-auto relative">
          {/* Connecting line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gray-200 z-0" />
          
          {experiences.map((exp, index) => (
            <div
              key={index}
              className={`relative z-10 flex items-center mb-16 last:mb-0 ${
                index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
              }`}
            >
              {/* Timeline node */}
              <div className="absolute left-1/2 transform -translate-x-1/2 w-12 h-12 rounded-full bg-white shadow-lg border-4 border-white">
                <div className={`w-full h-full rounded-full ${exp.color} animate-pulse`} />
              </div>
              
              {/* Content card */}
              <div className={`w-5/12 ${index % 2 === 0 ? 'pr-16' : 'pl-16'}`}>
                <div className="bg-white rounded-lg shadow-lg p-6 transform transition-all duration-300 hover:scale-105 hover:shadow-xl">
                  <div className="flex items-center mb-4">
                    <exp.icon className={`w-8 h-8 ${exp.iconColor} mr-3`} />
                    <h3 className="text-xl font-bold">{exp.title}</h3>
                  </div>
                  <p className="text-gray-600">{exp.description}</p>
                  
                  {/* Animated arrow */}
                  <div className="mt-4 flex justify-end">
                    <ArrowRight className={`w-5 h-5 ${exp.iconColor} animate-bounce-slow`} />
                  </div>
                </div>
              </div>
              
              {/* Spacer for opposite side */}
              <div className="w-5/12" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;