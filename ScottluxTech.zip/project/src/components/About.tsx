import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">About Me</h2>
        <div className="max-w-3xl mx-auto stagger-children">
          <p className="text-lg text-gray-700 mb-6 animate-fade-in hover-lift">
            I am a Masters graduate in Logistics Engineering from Yaşar Üniversitesi. My professional journey spans across information security,
            software development, and education, where I've consistently demonstrated my
            ability to deliver results and drive innovation.
          </p>
          <p className="text-lg text-gray-700 mb-6 animate-fade-in hover-lift">
            Currently serving as an ICT Instructor at Karsiayaka Koleji International in Izmir, Turkey, I combine my technical expertise with educational leadership to nurture the next generation of tech enthusiasts. Previously, I worked as a Junior SOC Analyst at the International Institute of Tropical Agriculture, where I strengthened my security skills.
          </p>
          <p className="text-lg text-gray-700 animate-fade-in hover-lift">
            I'm passionate about bridging the gap between technology and education, evidenced by my involvement in community initiatives like Teens Tech and Debug Hangout. My diverse skill set spans web development, information security, and management, making me a versatile professional in the tech industry.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;